#This part of code is the first part of our pipeline to transfer a classical midi file into jazz style
#This CycleGAN model is refer to a project in Github(https://github.com/sumuzhao/CycleGAN-Music-Style-Transfer)

- Environment setting:
python 3.6.13
tensorflow 1.4.0
numpy 1.19.5
pretty_midi 0.2.8
pypianoroll 0.1.3

To train or test model, you should first unzip the zipfile(in directory named datasets) which contains the datasets.
We have trained the model and save the checkpoints, save and compress it as "JC_J2JC_C_2022-12-05_base_0.0.zip", to use the
checkpoints, copy the "JC_J2JC_C_2022-12-05_base_0.0.zip" into directory named checkpoints and unzip it.

- Train a CycleGAN model:
```bash
python main.py --dataset_A_dir='JC_J' --dataset_B_dir='JC_C' --type='cyclegan' --model='base' --sigma_d=0 --phase='train'
```
There are three options for model, 'base', 'partial', 'full'. And different values can be set for sigma. 

- Test a CycleGAN model:
```bash
python main.py --dataset_A_dir='JC_C' --dataset_B_dir='JC_J' --type='cyclegan' --model='base' --sigma_d=0 --phase='test' --which_direction='AtoB'
```

After training, you can find sample midi in the directory named samples.
After testing, you can browse in directory named test, Go all the way to the bottom folder, enter the mid folder, which contains the midi file of the 
original test data(xxx_origin.mid) , the midi file used for the consistency loss calculation after the CycleGAN cycle(xxx_cycle.mid) and the final transferred 
midi file (xxx_transfer.mid), we have run the test command, so you can also directly choose to enter the folder to play these midi files to see the effect of the model

#The transferred test midi file(xxx_transfer.mid) will be used as the input in later part of our style transfer pipleline.